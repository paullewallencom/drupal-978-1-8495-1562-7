<?php


/**
 * @file
 * main template file
 */


?>
<div class="views-highcharts-chart" id="<?php print($chart_id); ?>" style="margin: 0 auto"></div>
