<?php

phpinfo();


?>